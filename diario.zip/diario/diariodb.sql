-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-11-2023 a las 03:39:53
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `diariodb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticias`
--

CREATE TABLE `noticias` (
  `id_noticia` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `titulo` text NOT NULL,
  `fecha` date NOT NULL,
  `copete` text NOT NULL,
  `cuerpo` varchar(50) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `categoria` varchar(30) NOT NULL,
  `autor` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `noticias`
--

INSERT INTO `noticias` (`id_noticia`, `id_usuario`, `titulo`, `fecha`, `copete`, `cuerpo`, `imagen`, `categoria`, `autor`) VALUES
(75, 52, 'Descubren tiburon de 500 años de edad', '2023-10-15', 'Los investigadores se toparon con el tiburon con mas de 500 años de edad', '<p>Ocurrio en la costa de Belice, donde por accide', '1697330966-tiburon.avif', 'Ciencias', 'Jorge Lopez'),
(76, 52, 'La union europea con mas salida laboral', '2023-10-15', 'Un informe revelo que en la union europea tienen el mas alto sueldo ', '<p>Un informe revelo que en la union europea tiene', '1697331083-images1.jpg', 'Sociales', 'Jorge Lopez'),
(77, 52, 'Argentina empato junto a Brazil', '2023-10-17', 'En un partido que se jugo en Brazil, empataron los dos rivales', '<p>Argentina empato frente a Brazil en un partido ', '1697504055-imagen3.JPG', 'Deportes', 'Jorge Lopez'),
(78, 53, 'Cordoba nuevamente bajo agua', '2023-10-19', 'Las inundaciones no paran en la ciudad , hubo evacuacion de casi toda una ciudad', '<p>El temporal sigue asotando a Cordoba y las inun', '1697676991-imagen7.jpg', 'Sociales', 'Veronica Moroni'),
(79, 53, 'Dolar imparable', '2023-10-19', 'El dolar sigue en suba y umentan los precios', '<p>La moneda estadounidense tuvo una gran suba est', '1697677112-image6.jpg', 'Economía', 'Veronica Moroni'),
(80, 53, 'Se jugara en españa el ultimo campeonato', '2023-10-22', 'Se vienen las Olimpiadas 2023 y el pais se prepara con todo', '<p>Podemos decir que sera&nbsp; un gran anfitrion ', '1697936432-imagen4.webp', 'Deportes', 'Veronica Moroni'),
(81, 1, 'SIC lo hizo de nuevo: derrotó a Hindú y jugará la final del Top 12 de la URBA contra Alumni', '2023-11-16', 'Se jugara el proximo domingo y se disputarna el primer puesto', '<p>Este domingo en cancha de Uruguay se jugara la ', '1700096708-imagen.jpg', 'Deportes', 'Gustavo Lafuente'),
(82, 51, 'Aumento para Jubilados', '2023-10-22', 'Los jubilados tendran un aumento del 22% y se incrementara por mes ', '<p>Recibiran&nbsp; los jubilados un aumento del 22', '1697936865-image6.jpg', 'Sociales', 'Carolina Diaz'),
(83, 51, 'El campo podra exportar sin que tenga retenciones', '2023-11-16', 'Se viene una buena noticia para el campo, no tendran retenciones', '<p>De acuerdo a un informe se vendran buenas notic', '1700097132-campo.jpg', 'Economía', 'Carolina Diaz'),
(84, 51, 'El trigo que se mantiene para consumo interno', '2023-10-30', 'Se vienen el aumento de impuestos al trigo ', '<p>El aumento provocara que el pais tenga mas cons', '1698628446-campo1.jpg', 'Economía', 'Carolina Diaz');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `tipo_usuario` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `apellido`, `usuario`, `password`, `tipo_usuario`) VALUES
(1, 'Gustavo', 'Lafuente', 'guillermo', 'guE1pk/6waGK2', ''),
(50, 'Noelia', 'Perez', 'noelia', 'noymb1HLKdtts', ''),
(51, 'Carolina', 'Diaz', 'carolina', 'cahP7bw2lDKuM', ''),
(52, 'Jorge', 'Lopez', 'jorge', 'joSkCWjoFfDD.', ''),
(53, 'Veronica', 'Moroni', 'veronica', 've8wciK0T08bk', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `noticias`
--
ALTER TABLE `noticias`
  ADD PRIMARY KEY (`id_noticia`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `noticias`
--
ALTER TABLE `noticias`
  MODIFY `id_noticia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
