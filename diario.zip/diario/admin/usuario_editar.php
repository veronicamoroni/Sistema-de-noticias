<?php
session_start();
extract($_REQUEST);
if (!isset($_SESSION['usuario_logueado']))
    header("location:index.php");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link href="../lib/bootstrap-5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="../lib/bootstrap-5.3.2/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        <?php require("menu.php"); ?>
        <div class="col-12 text-center">
         <h1>Modificar Usuario</h1>
        </div>
                            
        <?php
        require("conexion.php");
        $conexion = mysqli_connect($server_db, $usuario_db, $password_db)
            or die("No se puede conectar con el servidor");
        mysqli_select_db($conexion, $base_db)
            or die("No se puede seleccionar la base de datos");

        $instruccion= "select * from usuarios where id_usuario='$id_usuario'";
        $consulta=mysqli_query($conexion,$instruccion) or die("no pudo consultar");
        $resultado=mysqli_fetch_array($consulta);
       
        if(isset($mensaje))
        print("<h3 style='color:#0d6efd'>".$mensaje."</h3>");
        ?>
        
            
      
        <form action="usuario_editar_guardar.php" method="post" class="bg-secondary-subtle py-5 col-8 offset-2 card text-bg-light shadow-lg p-3 mt-3">
            <div class=" input-group input-group-sm mb-3">
                <label for="usuario" class="form-label">usuario</label>
                <input type="text" class="form-control" id="usuario" name="usuario" placeholder="usuario" required value="<?php print($resultado['usuario']);?>">
            </div>
            <div class=" input-group input-group-sm mb-3">
                <label for="nombre" class="form-label">nombre</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required value="<?php print($resultado['nombre']);?>">
            </div>
            <div class="input-group input-group-sm mb-3">
                <label for="apellido" class="form-label">apellido</label>
                <input type="text" class="form-control" id="apellido" name="apellido" required value="<?php print($resultado['apellido']);?>">
            </div>
            <div class=" input-group input-group-sm mb-3">
                <label for="correo" class="form-label">correo</label>
                <input type="text" class="form-control" id="correo" name="correo" required value="<?php print($resultado['correo']);?>">
            </div>
          
        
            <input class="btn btn-sm btn-dark" type="submit" id="enviar" name="enviar" value="GUARDAR">
                <a href="usuarios.php" class="btn btn-sm btn-dark">Regresar</a>
            </div>


        </form>

    </div>


</body>

</html>